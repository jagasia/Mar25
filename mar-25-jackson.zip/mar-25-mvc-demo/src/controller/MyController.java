package controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import model.Branch;

@Controller
public class MyController {

	@GetMapping("/")
	public String home()
	{
		return "index";
	}
	
	@GetMapping(value="/branch", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Branch> read()
	{
		Branch branch=new Branch("B00011", "Main branch", "Kolkata");
		return new ResponseEntity<Branch>(branch, HttpStatus.OK);
	}
	
	@PostMapping(value = "/branch" , consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public String create(@RequestBody Branch branch)
	{
		System.out.println("Received branch values");
		return branch.toString();
	}
	
	
}
