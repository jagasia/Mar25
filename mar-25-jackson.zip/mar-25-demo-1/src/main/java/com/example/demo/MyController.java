package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import model.Branch;

@Controller
public class MyController {

	@GetMapping("/")
	public String home()
	{
		return "index";
	}
	
	@GetMapping("/branches")
	@ResponseBody
	public List<Branch> read()
	{
		List<Branch> branches=new ArrayList<>();
		branches.add(new Branch("B00015","New branch","Kolkata"));
		branches.add(new Branch("B00011","Old branch","Chennai"));
		branches.add(new Branch("B00012","A branch","Mumbai"));
		branches.add(new Branch("B00013","Another branch","Noida"));
		
		return branches;
	}
	
	@GetMapping("/branch")
	@ResponseBody
	public Branch read(String bid)
	{
		return new Branch("B00015","New branch","Kolkata");
	}
	
	
}
