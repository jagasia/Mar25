package jag_group_1.em_demo_1;

import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import model.Vehicle;
import model.VehicleService;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("bean.xml");
    	
    	VehicleService vs=(VehicleService) ctx.getBean("vs");
//    	vs.update(new Vehicle(610,"Innova", "MUV", "Toyota"));
//    	vs.delete(610);
    	List<Vehicle> vehicles = vs.findVehicleByType("SUV");
    	for(Vehicle v:vehicles)
    		System.out.println(v);
//    	
//    	System.out.println(v);
        System.out.println( "Hello World!" );
    }
}
